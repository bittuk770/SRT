﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductManagement_BO;
using ProductManagement_BLL;

namespace ProductManagement_UI
{
    public partial class addProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DBClass_BLL dbObj = new DBClass_BLL();
            Product_BO prodObj = new Product_BO();
            prodObj.ProductName = TextProdName.Text;
            prodObj.CategoryID = Convert.ToInt32(DropCategory.SelectedValue);
            prodObj.Stock = TextStock.Text;
            prodObj.Description = TextDescription.Text;
            dbObj.addProduct(prodObj);
        }
    }
}