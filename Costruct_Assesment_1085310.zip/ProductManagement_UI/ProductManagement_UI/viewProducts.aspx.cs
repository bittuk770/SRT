﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductManagement_BLL;
using System.Data;

namespace ProductManagement_UI
{
    public partial class viewProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Session["prodid"]);
            DBClass_BLL dbObj = new DBClass_BLL();
            DataSet ds = new DataSet();
            ds = dbObj.viewProduct(id);
            GridProducts.DataSource = ds;
            GridProducts.DataBind();
        }
    }
}