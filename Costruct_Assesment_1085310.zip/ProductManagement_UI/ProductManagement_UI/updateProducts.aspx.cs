﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductManagement_BLL;
using ProductManagement_BO;
using System.Data;

namespace ProductManagement_UI
{
    public partial class updateProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
                gvBind();
        }

        protected void gvBind()
        {
            int id = Convert.ToInt32(Session["prodid"]);
            DBClass_BLL dbObj = new DBClass_BLL();
            DataSet ds = new DataSet();
            ds = dbObj.viewProduct(id);
            GridProducts.DataSource = ds;
            GridProducts.DataBind();
        }

        protected void GridProducts_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridProducts.EditIndex = e.NewEditIndex;
            gvBind();            
        }

        protected void GridProducts_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            DBClass_BLL dbObj = new DBClass_BLL();
            GridViewRow gvr = GridProducts.Rows[e.RowIndex];
            Product_BO prodObj = new Product_BO();
            prodObj.ProductID = Convert.ToInt32(Session["prodid"]);
            prodObj.Stock = (gvr.FindControl("TextStock") as TextBox).Text;
            prodObj.Description = (gvr.FindControl("TextDesc") as TextBox).Text;
            dbObj.updateProducts(prodObj);
            GridProducts.EditIndex = -1;
            gvBind();
        }

        protected void GridProducts_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridProducts.EditIndex = -1;
            gvBind();
        }
    }
}