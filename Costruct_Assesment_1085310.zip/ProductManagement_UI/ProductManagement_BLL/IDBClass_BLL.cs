﻿using System.Data;
using ProductManagement_BO;

namespace ProductManagement_BLL
{
    public interface IDBClass_BLL
    {
        void addProduct(Product_BO prodObj);
        void updateProducts(Product_BO prodObj);
        DataSet viewProduct(int id);
    }
}