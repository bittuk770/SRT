﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ProductManagement_BO;
using ProductManagement_DAL;

namespace ProductManagement_BLL
{
    public class DBClass_BLL : IDBClass_BLL
    {
        public void addProduct(Product_BO prodObj)
        {
            DBClass_DAL dbObj = new DBClass_DAL();
            dbObj.addProduct(prodObj);
        }
        public DataSet viewProduct(int id)
        {
            DBClass_DAL dbObj = new DBClass_DAL();
            DataSet ds = new DataSet();
            ds = dbObj.viewProduct(id);
            return ds;
        }
        public void updateProducts(Product_BO prodObj)
        {
            DBClass_DAL dbObj = new DBClass_DAL();
            dbObj.updateProducts(prodObj);
        }
    }
}
