﻿using System.Data;
using ProductManagement_BO;

namespace ProductManagement_DAL
{
    public interface IDBClass_DAL
    {
        void addProduct(Product_BO prodObj);
        void updateProducts(Product_BO prodObj);
        DataSet viewProduct(int id);
    }
}