﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using ProductManagement_BO;

namespace ProductManagement_DAL
{
    public class DBClass_DAL : IDBClass_DAL
    {
        
        public void addProduct(Product_BO prodObj)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbCon"].ConnectionString);
            SqlCommand cmd = new SqlCommand("usp_addProduct_1085310", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name",prodObj.ProductName);
            cmd.Parameters.AddWithValue("@catid",prodObj.CategoryID);
            cmd.Parameters.AddWithValue("@stock",prodObj.Stock);
            cmd.Parameters.AddWithValue("@desc",prodObj.Description);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public DataSet viewProduct(int id)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbCon"].ConnectionString);
            SqlCommand cmd = new SqlCommand("usp_viewProduct_1085310", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@prodid", id);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter();
            con.Open();
            da.SelectCommand = cmd;
            da.Fill(ds);
            con.Close();
            return ds;
        }
        public void updateProducts(Product_BO prodObj)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbCon"].ConnectionString);
            SqlCommand cmd = new SqlCommand("usp_updateProduct_1085310", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@prodid", prodObj.ProductID);
            cmd.Parameters.AddWithValue("@stock", prodObj.Stock);
            cmd.Parameters.AddWithValue("@desc", prodObj.Description);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
