﻿namespace ProductManagement_BO
{
    public interface IProduct_BO
    {
        int CategoryID { get; set; }
        string Description { get; set; }
        int ProductID { get; set; }
        string ProductName { get; set; }
        string Stock { get; set; }
    }
}