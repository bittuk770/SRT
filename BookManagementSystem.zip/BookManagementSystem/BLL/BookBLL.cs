﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
using System.Data;

namespace BLL
{
    public class BookBLL
    {
        public int addBook(BookBO obj)
        {
            BookDAL objclss = new BookDAL();

            return objclss.addBook(obj);

        }
        public DataTable viewBook(BookBO obj)
        {


            BookDAL objclss = new BookDAL();
            return objclss.viewBook(obj);


        }
        public int deleteBook(BookBO obj)
        {
            BookDAL objclss = new BookDAL();

            return objclss.deleteBook(obj);

        }
    }
}
