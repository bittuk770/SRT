﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;
using System.Web.Security;


namespace BookManagementSystem
{
    public partial class addbook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtcategory.Value = Session["category"].ToString();

            //txtcategory.EnableViewState = false;
        }

        protected void submit_Click(object sender, EventArgs e)
        {

            BookBO book = new BookBO();
            book.BookName = txtname.Value.ToString();
            book.Author = txtauthor.Value.ToString();
            book.Category=txtcategory.Value.ToString();
            book.Price = long.Parse(txtprice.Value.ToString());
           // book.Category = txtcategory.Value.ToString();
            BookBLL bookbll = new BookBLL();
            int result = bookbll.addBook(book);
            if(result>0)
            {
                Response.Write("<script>alert('DONE ID IS " + result + "')</script>");
            }
            else if (result == -2)
            {
                Response.Write("<script>alert('NOT DONE')</script>");

               
            }
            else
                Response.Write("<script>alert('DONE but id cannot be shown')</script>");


        }
    }
}