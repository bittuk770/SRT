﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;
using System.Web.Security;

namespace BookManagementSystem
{
    public partial class deletebook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            BookBO book = new BookBO();
            BookBLL bookbll = new BookBLL();
            int result = bookbll.deleteBook(book);
            if (result > 1)
            {
                Response.Write("<script>alert('DELETE THE ID: " + result + "')</script>");
            }
            else if (result == -2)
            {
                Response.Write("<script>alert('NOT DELETED')</script>");


            }
            else
                Response.Write("<script>alert('NOT DELETED')</script>");


        }
    }
}